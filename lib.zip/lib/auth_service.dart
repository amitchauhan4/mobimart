import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  // 🔹 Login Function
  static Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
  }) async {
    final url = Uri.parse(
      "https://bmdublog.com/my_mobi_mart/api/customer/login",
    );

    try {
      final response = await http.post(
        url,
        body: {"phone": phone, "password": password},
      );

      return jsonDecode(response.body);
    } catch (e) {
      return {"status": false, "message": "Login error: $e"};
    }
  }

  // 🔹 Sign Up Function
  static Future<Map<String, dynamic>> signUp({
    required String name,
    required String phone,
    required String password,
    required String confirmPassword,
  }) async {
    final url = Uri.parse(
      "https://bmdublog.com/my_mobi_mart/api/customer/sign-up",
    );

    try {
      final response = await http.post(
        url,
        body: {
          "name": name,
          "phone": phone,
          "password": password,
          "confirm_password": confirmPassword, // ✅ include confirmPassword
        },
      );

      return jsonDecode(response.body);
    } catch (e) {
      return {"status": false, "message": "Sign up error: $e"};
    }
  }
}
